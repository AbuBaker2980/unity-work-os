import React, { useState } from 'react';
import {
    Book, Shield, Download, MessageSquare, Users,
    FileText, Zap, ChevronRight, Menu, X, Search
} from 'lucide-react';

const DocsView = () => {
    const [activeSection, setActiveSection] = useState('intro');
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
            setActiveSection(id);
            setMobileMenuOpen(false);
        }
    };

    const sections = [
        { id: 'intro', title: 'Introduction', icon: <Book size={18} /> },
        { id: 'install', title: 'Installation & Setup', icon: <Download size={18} /> },
        { id: 'communication', title: 'Chat & File Sharing', icon: <MessageSquare size={18} /> }, // Drag & Drop Mentioned here
        { id: 'roles', title: 'Team Roles & Permissions', icon: <Users size={18} /> },
        { id: 'security', title: 'Security & Privacy', icon: <Shield size={18} /> },
    ];

    return (
        <div className="min-h-screen bg-[#0a0a0a] text-gray-300 font-sans flex flex-col md:flex-row">

            {/* --- MOBILE HEADER --- */}
            <div className="md:hidden flex items-center justify-between p-4 border-b border-white/10 bg-[#151518]">
                <div className="font-bold text-white flex items-center gap-2">
                    <Book className="text-blue-500" /> Docs
                </div>
                <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-white">
                    {mobileMenuOpen ? <X /> : <Menu />}
                </button>
            </div>

            {/* --- SIDEBAR NAVIGATION --- */}
            <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#151518] border-r border-white/10 transform transition-transform duration-300 md:relative md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="p-6 border-b border-white/10">
                    <h1 className="text-2xl font-bold text-white tracking-tight">Unity <span className="text-blue-500">Docs</span></h1>
                    <p className="text-xs text-gray-500 mt-1">v1.0.2 Documentation</p>
                </div>

                <nav className="p-4 space-y-1">
                    {sections.map((section) => (
                        <button
                            key={section.id}
                            onClick={() => scrollToSection(section.id)}
                            className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all ${activeSection === section.id
                                    ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                                }`}
                        >
                            {section.icon}
                            {section.title}
                            {activeSection === section.id && <ChevronRight size={14} className="ml-auto" />}
                        </button>
                    ))}
                </nav>

                <div className="absolute bottom-0 left-0 w-full p-6 bg-gradient-to-t from-[#0a0a0a] to-transparent">
                    <a href="/" className="block w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-center rounded-lg text-sm font-bold transition-colors">
                        Back to App
                    </a>
                </div>
            </aside>

            {/* --- MAIN CONTENT --- */}
            <main className="flex-1 h-screen overflow-y-auto custom-scrollbar scroll-smooth">
                <div className="max-w-4xl mx-auto p-8 md:p-12 space-y-16">

                    {/* 1. INTRODUCTION */}
                    <section id="intro" className="space-y-6 animate-fade-in">
                        <div className="space-y-2">
                            <h2 className="text-4xl font-bold text-white">Unity Work OS Documentation</h2>
                            <p className="text-xl text-blue-400">The central operating system for modern dev teams.</p>
                        </div>
                        <p className="text-gray-400 leading-relaxed text-lg">
                            Unity Work OS is a unified platform designed to streamline communication, project management, and asset sharing for software development teams. It replaces scattered tools with a single, encrypted digital workspace.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                            <FeatureCard icon={<Zap size={20} />} title="Fast" desc="Real-time syncing via Firestore." />
                            <FeatureCard icon={<Shield size={20} />} title="Secure" desc="Encrypted data & role-based access." />
                            <FeatureCard icon={<FileText size={20} />} title="Organized" desc="Drag & Drop file management." />
                        </div>
                    </section>

                    <hr className="border-white/10" />

                    {/* 2. INSTALLATION */}
                    <section id="install" className="space-y-6">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400"><Download /></div>
                            <h3 className="text-2xl font-bold text-white">Installation & Updates</h3>
                        </div>
                        <div className="prose prose-invert max-w-none text-gray-400">
                            <p>Unity Work OS is available as a native Windows application for maximum performance.</p>
                            <ul className="list-disc pl-5 space-y-2 mt-4">
                                <li>Download the latest <code>.exe</code> installer from the Home page.</li>
                                <li>Run the installer (No admin privileges required).</li>
                                <li>The app will automatically launch after installation.</li>
                            </ul>

                            <div className="bg-[#151518] border border-blue-500/20 p-4 rounded-xl mt-6">
                                <h4 className="text-white font-bold flex items-center gap-2 mb-2">
                                    <Zap size={16} className="text-yellow-400" /> Auto-Updates
                                </h4>
                                <p className="text-sm">
                                    You don't need to manually update. The app checks for new versions (like <strong>v1.0.2</strong>) in the background. If an update is found, it will install automatically next time you restart the app.
                                </p>
                            </div>
                        </div>
                    </section>

                    <hr className="border-white/10" />

                    {/* 3. COMMUNICATION (New Drag & Drop) */}
                    <section id="communication" className="space-y-6">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-green-500/20 rounded-lg text-green-400"><MessageSquare /></div>
                            <h3 className="text-2xl font-bold text-white">Communication & Files</h3>
                        </div>
                        <p className="text-gray-400">
                            The core of Unity Work OS is the Team Chat and Project Chat modules. All messages are encrypted and synced instantly.
                        </p>

                        <div className="space-y-6 mt-4">
                            <div>
                                <h4 className="text-lg font-bold text-white mb-2">Drag & Drop File Sharing <span className="text-[10px] bg-blue-600 px-2 py-0.5 rounded text-white ml-2">NEW v1.0.2</span></h4>
                                <p className="text-sm text-gray-400 mb-3">
                                    Sharing assets is now easier than ever. You can drag files directly from your desktop into the chat window.
                                </p>
                                <div className="bg-[#151518] p-4 rounded-lg border border-white/5 border-dashed">
                                    <ul className="space-y-2 text-sm text-gray-300">
                                        <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span> <strong>Images:</strong> PNG, JPG, GIF (Auto-preview in chat).</li>
                                        <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span> <strong>Videos:</strong> MP4, WEBM (Playable inside app).</li>
                                        <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span> <strong>Documents:</strong> PDF, ZIP, RAR (Direct download links).</li>
                                    </ul>
                                </div>
                            </div>

                            <div>
                                <h4 className="text-lg font-bold text-white mb-2">Mentions & Notifications</h4>
                                <p className="text-sm text-gray-400">
                                    Use <code>@Username</code> to notify a specific team member. They will see a highlighted tag in their chat stream.
                                </p>
                            </div>
                        </div>
                    </section>

                    <hr className="border-white/10" />

                    {/* 4. ROLES */}
                    <section id="roles" className="space-y-6">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-purple-500/20 rounded-lg text-purple-400"><Users /></div>
                            <h3 className="text-2xl font-bold text-white">Roles & Permissions</h3>
                        </div>
                        <p className="text-gray-400">
                            Every team member is assigned a specific role that defines their permissions and visual identity in the roster.
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                            <RoleCard role="Team Lead (TL)" color="text-purple-400 border-purple-500/20" desc="Full admin access. Can manage team name, remove members, and assign roles." />
                            <RoleCard role="Developer" color="text-blue-400 border-blue-500/20" desc="Standard access to code repositories, tasks, and team chats." />
                            <RoleCard role="Designer" color="text-pink-400 border-pink-500/20" desc="Access to design assets and UI/UX project boards." />
                            <RoleCard role="QA / Tester" color="text-red-400 border-red-500/20" desc="Focused on bug reporting and task verification." />
                        </div>
                    </section>

                    <hr className="border-white/10" />

                    {/* 5. SECURITY */}
                    <section id="security" className="space-y-6 pb-20">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-400"><Shield /></div>
                            <h3 className="text-2xl font-bold text-white">Security Architecture</h3>
                        </div>
                        <div className="bg-[#151518] p-6 rounded-xl border border-white/5 space-y-4">
                            <div className="flex gap-4">
                                <div className="shrink-0"><Shield className="text-green-500" /></div>
                                <div>
                                    <h4 className="text-white font-bold">End-to-End Encryption</h4>
                                    <p className="text-sm text-gray-400 mt-1">
                                        All chat messages and file transfers are encrypted using Google Cloud Security standards before being stored in Firestore/Storage.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-4">
                                <div className="shrink-0"><Users className="text-blue-500" /></div>
                                <div>
                                    <h4 className="text-white font-bold">Isolated Workspaces</h4>
                                    <p className="text-sm text-gray-400 mt-1">
                                        Data is strictly segregated by <code>TeamID</code>. A user cannot access messages or files from a team they do not belong to.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </section>

                </div>
            </main>
        </div>
    );
};

// Helper Components
const FeatureCard = ({ icon, title, desc }) => (
    <div className="bg-[#151518] p-4 rounded-xl border border-white/5 hover:border-blue-500/30 transition-colors">
        <div className="text-blue-400 mb-3">{icon}</div>
        <h4 className="text-white font-bold mb-1">{title}</h4>
        <p className="text-xs text-gray-500">{desc}</p>
    </div>
);

const RoleCard = ({ role, color, desc }) => (
    <div className={`p-4 rounded-xl border bg-[#151518] ${color}`}>
        <h4 className="font-bold text-white mb-2">{role}</h4>
        <p className="text-xs text-gray-400">{desc}</p>
    </div>
);

export default DocsView;